<?php

// List of versions to check for the upgrade path.
// Add new versions to the end of the array - and remember the comma!
$versionPath = array(
'1.0.2',
'2.0-alpha',
'2.0-beta',
'2.0',
'2.0.1',
'2.0.2',
'2.0.3',
'2.0.4',
'2.1-rc1',
'2.1-rc2',
'2.1',
'2.1.1',
'2.1.2',
'2.1.3',
'2.1.4',
'2.1.5',
'2.1.6',
'2.1.7',
);
