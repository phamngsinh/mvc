<?php
if (!defined('DP_BASE_DIR')) {
  die('You should not access this file directly.');
}
?>
<img src="images/shim.gif" width="1" height="5" alt="" border="0"><br />
<table width="98%" cellspacing="1" cellpadding="0" border="0">
	<tr>
	<td><img src="./images/icons/dp.gif" alt="" border="0"></td>
		<td nowrap="nowrap" width="100%"><h1><?php echo $AppUI->_('Access Denied');?></h1></td>
	</tr>
</table>

<p>
<table width="95%" border=0 cellpadding="5" cellspacing=0>
<tr valign=top>
	<td width=50%><?php echo $AppUI->_('accessDeniedMsg');?></td>
	<td width=50%>&nbsp;</td>
</tr>
</table>
</p>